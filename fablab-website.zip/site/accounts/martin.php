<?php if(!defined('KIRBY')) exit ?>

username: martin
email: martin@waag.org
password: >
  $2a$10$YCRCisvuJyE.Ag6TvbArtOxqW2C0bNeI7OxNmt.X.iCWB41UcdMkG
language: en
role: admin
history:
  - projects
  - how-to-document
  - i-want-to-make
  - faq
  - open-day
