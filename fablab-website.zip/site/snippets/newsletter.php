<section class="newsletter standard-padding one-col left">
  <!-- Begin MailChimp Signup Form -->
  <div id="mc_embed_signup" class="standard-padding white-text" >
    <h2>Signup for the Fablab Waag Society newsletter</h2>
    <form action="//waag.us8.list-manage.com/subscribe/post?u=66503a9e5c0ff3e33fee3b344&amp;id=72c437033a" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
        <div id="mc_embed_signup_scroll">

    	<input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="Email address" required>
        <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
        <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_66503a9e5c0ff3e33fee3b344_72c437033a" tabindex="-1" value=""></div>
        <div class="clear">
        <button type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button btn-2">Subscribe</button>
        </div>
    </form>
  </div>

  <!--End mc_embed_signup-->
</section>
