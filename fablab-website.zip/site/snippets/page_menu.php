<div class="hamburger-menu" data-openselector=".slide-menu">
  <div class="habmburer__inner">
    <span></span>
    <span></span>
    <span></span>
  </div>
</div>
<a href="<?php echo url(); ?>" class="home_btn">
  <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
   width="40px" height="40px" viewBox="0 0 40 40" enable-background="new 0 0 40 40" xml:space="preserve">
  <rect x="-5.141" y="16.858" transform="matrix(0.7071 0.7071 -0.7071 0.7071 20.0011 -8.2841)" fill="#414042" width="50.282" height="6.284"/>
  <rect x="-5.142" y="16.857" transform="matrix(-0.7071 0.7071 -0.7071 -0.7071 48.2821 19.9994)" fill="#414042" width="50.282" height="6.284"/>
  </svg>
</a>
