<div class="hamburger-menu" data-openselector=".slide-menu">
  <div class="habmburer__inner">
    <span></span>
    <span></span>
    <span></span>
  </div>
</div>
