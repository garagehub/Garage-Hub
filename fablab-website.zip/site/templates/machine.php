<?php snippet('header') ?>

  <main class="main defaultPage changecolorblack" role="main">
  <div class="booking_reservering">
    <a href="http://www.supersaas.com/schedule/fablab_AMS/Equipment" class="btn btn-2 btn-2a">Make a reservation</a>
  </div>
    <div class="text">
      <h1><?php echo $page->title()->html() ?></h1>
      <?php echo $page->text()->kirbytext() ?>
    </div>
  </main>
<?php snippet('footer') ?>
