# Kirby Panel

This is the Kirby Panel submodule.

Please refer to the [Kirby Starterkit](http://github.com/getkirby/starterkit)
for a complete installation of Kirby

## Author
Bastian Allgeier
<bastian@getkirby.com>

## Website
<http://getkirby.com>

## License
<http://getkirby.com>