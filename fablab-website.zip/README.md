# Fablab 2016 website

This is the new Fablab website build with Kirby

## Author
Waag Society
<http://waag.org>

## Website
<http://fablab.waag.org>
<http://waag.org>

## Kirby
<https://github.com/getkirby/kirby>
<http://getkirby.com>

## License
<http://getkirby.com>

## Plugins
Kirby-Color-Picker
<https://github.com/ian-cox/Kirby-Color-Picker>

## Instructions
npm install <br />
bower install enquire <br />
gulp <br />
gulp start